# Production deployment

1. Create a GitHub repository and upload this project.
2. In Render, create a Blueprint from the repository (`render.yaml`).
3. Render creates a Python web service and PostgreSQL database.
4. Add the secret environment variables in the Render dashboard:
   ADZUNA_APP_ID
   ADZUNA_APP_KEY
   JOOBLE_API_KEY
   ADMIN_TOKEN
5. Deploy.
6. Use the generated HTTPS URL as the website address.
7. The app serves frontend and backend from the same domain, so no localhost API URL is used in production.

## Live sync
POST `/api/sync` with header:
`X-Admin-Token: <ADMIN_TOKEN>`

Schedule this endpoint with a cron/scheduler every 15–30 minutes. The frontend refreshes its displayed jobs every 30 minutes too.

## API credentials
Adzuna requires an app_id and app_key.
Jooble requires a domain-specific API key for each country/market. Do not put either credential in frontend JavaScript.

## Important
Do not paste secret keys into GitHub, screenshots, public chat, frontend JavaScript, or HTML. Use Render's Environment Variables / secret settings.
