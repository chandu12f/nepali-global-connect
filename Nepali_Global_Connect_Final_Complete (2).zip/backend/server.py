import os, sqlite3, hashlib, time
from datetime import datetime, timezone
import requests
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND=os.path.join(BASE,"frontend")
DATABASE_URL=os.getenv("DATABASE_URL","").strip()
DB_PATH=os.getenv("DB_PATH",os.path.join(os.path.dirname(__file__),"reunion.db"))
ADMIN_TOKEN=os.getenv("ADMIN_TOKEN","change-this-admin-token")
app=Flask(__name__, static_folder=FRONTEND, static_url_path="")
CORS(app)

def now(): return datetime.now(timezone.utc).isoformat()

def db():
    if DATABASE_URL.startswith(("postgres://","postgresql://")):
        import psycopg
        return psycopg.connect(DATABASE_URL)
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c

def pg():
    return DATABASE_URL.startswith(("postgres://","postgresql://"))

def init():
    c=db()
    if pg():
        sql="""
        CREATE TABLE IF NOT EXISTS members(id SERIAL PRIMARY KEY,name TEXT,email TEXT UNIQUE,country TEXT,status TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS subscribers(id SERIAL PRIMARY KEY,email TEXT UNIQUE,created_at TEXT);
        CREATE TABLE IF NOT EXISTS likes(id SERIAL PRIMARY KEY,ip_hash TEXT UNIQUE,created_at TEXT);
        CREATE TABLE IF NOT EXISTS jobs(id SERIAL PRIMARY KEY,external_id TEXT UNIQUE,title TEXT,company TEXT,location TEXT,country TEXT,type TEXT,salary TEXT,description TEXT,apply_url TEXT,source TEXT,updated_at TEXT,expires_at TEXT);
        CREATE TABLE IF NOT EXISTS sync_log(id SERIAL PRIMARY KEY,source TEXT,created_at TEXT,status TEXT,details TEXT);
        """
        c.execute(sql)
    else:
        c.executescript("""CREATE TABLE IF NOT EXISTS members(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,email TEXT UNIQUE,country TEXT,status TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS subscribers(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE,created_at TEXT);
        CREATE TABLE IF NOT EXISTS likes(id INTEGER PRIMARY KEY AUTOINCREMENT,ip_hash TEXT UNIQUE,created_at TEXT);
        CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY AUTOINCREMENT,external_id TEXT UNIQUE,title TEXT,company TEXT,location TEXT,country TEXT,type TEXT,salary TEXT,description TEXT,apply_url TEXT,source TEXT,updated_at TEXT,expires_at TEXT);
        CREATE TABLE IF NOT EXISTS sync_log(id INTEGER PRIMARY KEY AUTOINCREMENT,source TEXT,created_at TEXT,status TEXT,details TEXT);""")
    c.commit()
    c.close()
init()

def execute(sql,args=()):
    c=db()
    if pg(): sql=sql.replace("?","%s")
    cur=c.cursor(); cur.execute(sql,args); c.commit()
    try: rows=cur.fetchall()
    except Exception: rows=[]
    c.close(); return rows

def count(table):
    c=db(); cur=c.cursor()
    cur.execute(f"SELECT COUNT(*) FROM {table}")
    n=cur.fetchone()[0]; c.close(); return n

COUNTRIES={"gb":"UK","us":"USA","ca":"Canada","au":"Australia","nz":"New Zealand","de":"Germany","ie":"Ireland","jp":"Japan","kr":"South Korea","nl":"Netherlands","ae":"UAE"}

def upsert(j):
    c=db()
    vals=(j["external_id"],j["title"],j.get("company",""),j.get("location",""),j.get("country","Other"),j.get("type",""),j.get("salary",""),j.get("description",""),j.get("apply_url",""),j.get("source",""),now(),j.get("expires_at"))
    if pg():
        c.execute("""INSERT INTO jobs(external_id,title,company,location,country,type,salary,description,apply_url,source,updated_at,expires_at)
        VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        ON CONFLICT(external_id) DO UPDATE SET title=EXCLUDED.title,company=EXCLUDED.company,location=EXCLUDED.location,country=EXCLUDED.country,type=EXCLUDED.type,salary=EXCLUDED.salary,description=EXCLUDED.description,apply_url=EXCLUDED.apply_url,source=EXCLUDED.source,updated_at=EXCLUDED.updated_at,expires_at=EXCLUDED.expires_at""",vals)
    else:
        c.execute("""INSERT OR REPLACE INTO jobs(external_id,title,company,location,country,type,salary,description,apply_url,source,updated_at,expires_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",vals)
    c.commit();c.close()

def adzuna():
    app_id=os.getenv("ADZUNA_APP_ID"); key=os.getenv("ADZUNA_APP_KEY")
    if not app_id or not key:return 0,"credentials not configured"
    total=0
    countries=[x.strip() for x in os.getenv("ADZUNA_COUNTRIES","gb,us,ca,au,nz,de,ie,jp").split(",") if x.strip()]
    for cc in countries:
        for kw in os.getenv("JOB_KEYWORDS","graduate software engineer,software developer,internship,data analyst").split(","):
            try:
                u=f"https://api.adzuna.com/v1/api/jobs/{cc}/search/1"
                r=requests.get(u,params={"app_id":app_id,"app_key":key,"results_per_page":30,"what":kw.strip(),"content-type":"application/json"},timeout=20);r.raise_for_status()
                for x in r.json().get("results",[]):
                    upsert({"external_id":"adzuna-"+str(x.get("id")),"title":x.get("title",""),"company":(x.get("company") or {}).get("display_name",""),"location":(x.get("location") or {}).get("display_name",""),"country":COUNTRIES.get(cc,"Other"),"type":"Full-time","salary":str(x.get("salary_min") or ""), "description":(x.get("description") or "")[:1800],"apply_url":x.get("redirect_url",""),"source":"Adzuna"})
                    total+=1
            except Exception as e: print("Adzuna error",cc,kw,e)
    return total,"ok"

def jooble():
    key=os.getenv("JOOBLE_API_KEY")
    if not key:return 0,"credentials not configured"
    total=0
    for loc in [x.strip() for x in os.getenv("JOOBLE_LOCATIONS","United States,Canada,United Kingdom,Australia,Germany,Ireland,Japan,South Korea,Netherlands,UAE").split(",")]:
        try:
            r=requests.post(f"https://jooble.org/api/{key}",json={"keywords":os.getenv("JOB_KEYWORDS","software developer"),"location":loc,"page":1,"ResultOnPage":50},timeout=20);r.raise_for_status()
            for x in r.json().get("jobs",[]):
                country=next((v for v in COUNTRIES.values() if v.lower() in loc.lower()),"Other")
                upsert({"external_id":"jooble-"+str(x.get("id")),"title":x.get("title",""),"company":x.get("company",""),"location":x.get("location",""),"country":country,"type":x.get("type",""),"salary":x.get("salary",""),"description":x.get("snippet",""),"apply_url":x.get("link",""),"source":"Jooble"})
                total+=1
        except Exception as e: print("Jooble error",loc,e)
    return total,"ok"

def sync_all():
    a=adzuna(); j=jooble()
    execute("INSERT INTO sync_log(source,created_at,status,details) VALUES(?,?,?,?)",("job-feeds",now(),"completed",f"Adzuna={a[0]} ({a[1]}), Jooble={j[0]} ({j[1]})"))
    return a,j

@app.get("/")
def home(): return send_from_directory(FRONTEND,"index.html")
@app.get("/<path:path>")
def static_files(path): return send_from_directory(FRONTEND,path)
@app.get("/health")
def health(): return jsonify(ok=True,time=now())

@app.get("/api/jobs")
def jobs():
    c=db(); cur=c.cursor()
    if pg(): cur.execute("SELECT * FROM jobs WHERE expires_at IS NULL OR expires_at > %s ORDER BY updated_at DESC",(now(),))
    else: cur.execute("SELECT * FROM jobs WHERE expires_at IS NULL OR expires_at > ? ORDER BY updated_at DESC",(now(),))
    cols=[d[0] for d in cur.description]; rows=[dict(zip(cols,r)) for r in cur.fetchall()]; c.close()
    return jsonify(jobs=rows,updated_at=now(),live_sources=bool(os.getenv("ADZUNA_APP_ID") or os.getenv("JOOBLE_API_KEY")))

@app.get("/api/stats")
def stats(): return jsonify(members=count("members"),subscribers=count("subscribers"),likes=count("likes"))

@app.post("/api/like")
def like():
    h=hashlib.sha256((request.remote_addr or "unknown").encode()).hexdigest()
    try: execute("INSERT INTO likes(ip_hash,created_at) VALUES(?,?)", (h,now()))
    except Exception: pass
    return jsonify(ok=True)

@app.post("/api/subscribe")
def subscribe():
    e=(request.json or {}).get("email","").strip().lower()
    if not e:return jsonify(message="Email required"),400
    try: execute("INSERT INTO subscribers(email,created_at) VALUES(?,?)",(e,now()))
    except Exception: pass
    return jsonify(message="Subscribed successfully")

@app.post("/api/members")
def member():
    x=request.json or {}
    if any(not x.get(k) for k in ["name","email","country","status"]): return jsonify(message="All fields are required"),400
    try:
        if pg(): execute("INSERT INTO members(name,email,country,status,created_at) VALUES(?,?,?,?,?) ON CONFLICT(email) DO UPDATE SET name=EXCLUDED.name,country=EXCLUDED.country,status=EXCLUDED.status",(x["name"],x["email"].lower(),x["country"],x["status"],now()))
        else: execute("INSERT OR REPLACE INTO members(name,email,country,status,created_at) VALUES(?,?,?,?,?)",(x["name"],x["email"].lower(),x["country"],x["status"],now()))
    except Exception: pass
    return jsonify(message="Welcome to the community")

@app.post("/api/sync")
def sync():
    if request.headers.get("X-Admin-Token")!=ADMIN_TOKEN:return jsonify(error="Unauthorized"),401
    a,j=sync_all(); return jsonify(ok=True,adzuna=a,jooble=j)

@app.post("/api/jobs")
def add_job():
    if request.headers.get("X-Admin-Token")!=ADMIN_TOKEN:return jsonify(error="Unauthorized"),401
    x=request.json or {}
    if not x.get("title") or not x.get("apply_url"):return jsonify(error="title and apply_url required"),400
    x.setdefault("external_id","community-"+str(time.time_ns())); upsert(x); return jsonify(ok=True)

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","5000")))
