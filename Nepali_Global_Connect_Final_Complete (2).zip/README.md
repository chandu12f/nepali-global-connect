# Nepali Global Connect — Live Job Portal

## What is included
- Student-facing international vacancy board
- Country, keyword and work-type filters
- Apply Now buttons that open the original job/application URL
- SQLite backend database
- Student Join form
- Subscriber database
- Likes
- Adzuna API connector
- Jooble REST API connector
- Admin-protected manual sync endpoint
- Automatic frontend refresh every 30 minutes
- No API secrets in frontend code

## IMPORTANT: this is Python/Flask, not Node/Express

### 1. Install Python
Install Python 3.11+ on Windows.

### 2. Open backend folder
Extract this ZIP and open CMD/PowerShell inside:
`backend`

### 3. Create virtual environment
`py -m venv .venv`

### 4. Activate
`.venv\Scripts\activate`

### 5. Install packages
`pip install -r requirements.txt`

### 6. Configure API keys
Copy `.env.example` to `.env`.

For Adzuna, register for an app ID/key and put them in:
`ADZUNA_APP_ID=...`
`ADZUNA_APP_KEY=...`

For Jooble, obtain the appropriate API key and put:
`JOOBLE_API_KEY=...`

Do NOT put these keys in frontend/app.js.

### 7. Start backend
`python server.py`

### 8. Start frontend
In another terminal:
`cd frontend`
`py -m http.server 5500`

Open:
`http://localhost:5500`

Password:
`Prathana@89133`

## Live vacancy sync
The backend exposes:
`POST /api/sync`

It requires:
`X-Admin-Token: YOUR_ADMIN_TOKEN`

Example PowerShell:
`Invoke-WebRequest -Method POST http://localhost:5000/api/sync -Headers @{"X-Admin-Token"="YOUR_ADMIN_TOKEN"}`

For true automatic backend synchronization every 15–30 minutes, schedule this endpoint/script using Windows Task Scheduler or your hosting provider's cron/scheduler.

The frontend itself refreshes its displayed job list every 30 minutes.

## Student Apply flow
Students click **Apply Now**. The browser opens the original vacancy/application URL supplied by the job provider. The portal does not impersonate the employer or collect employer login credentials.

## Data/source note
Use job APIs/RSS feeds only according to their terms and licensing. Adzuna provides a job-ad API for websites and requires an app ID/key. Jooble provides a REST API and states that regional domains can require separate keys and that API usage is subject to its terms.

## Production checklist
- HTTPS
- PostgreSQL instead of SQLite for larger traffic
- Server-side admin authentication
- Email verification and unsubscribe
- Rate limiting
- Moderation for community-submitted vacancies
- Automatic expiry/deletion of old jobs
- Scheduled backend sync
- Backups
- Privacy policy and terms
- Provider attribution as required by each API
