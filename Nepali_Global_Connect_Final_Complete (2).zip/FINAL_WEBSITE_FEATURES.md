# Nepali Global Connect (NGC)

**Tagline:** जोडिनुहोस् • अध्ययन गर्नुहोस् • काम गर्नुहोस् • अगाडि बढ्नुहोस् / Connect • Study • Work • Grow

## Included
- Nepali + English bilingual website interface
- Original NGC logo and Nepal-inspired branding
- Original Himalayan mountain artwork
- Nepal culture / national anthem section linking to the official source
- Nepali students worldwide community
- International job and internship vacancy board
- Country, keyword and work-type filtering
- Apply Now links to the original employer/job source
- Student/member registration
- Subscriber and like features
- Flask backend and database
- PostgreSQL-ready production configuration
- Adzuna and Jooble API connectors
- Protected admin job synchronization endpoint
- Production Gunicorn configuration
- Render deployment configuration
- API secrets kept on the backend/environment, not frontend

## Important
Live vacancies require valid Adzuna/Jooble credentials and successful synchronization.
Do not publish API keys in the frontend or GitHub repository.
